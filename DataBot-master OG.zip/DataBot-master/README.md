         ▄▀▀█▄▄   ▄▀▀█▄   ▄▀▀▀█▀▀▄  ▄▀▀█▄  
        █ ▄▀   █ ▐ ▄▀ ▀▄ █    █  ▐ ▐ ▄▀ ▀▄ 
        ▐ █    █   █▄▄▄█ ▐   █       █▄▄▄█ 
          █    █  ▄▀   █    █       ▄▀   █ 
         ▄▀▄▄▄▄▀ █   ▄▀   ▄▀       █   ▄▀  
        █     ▐  ▐   ▐   █         ▐   ▐   
        ▐                ▐                 
        
    This is the workspace for the databot, a chatbot for evaluating any
    code that is runnable on tryitonline.net. For more information, see:
        http://chat.stackexchange.com/rooms/35039/ppcg-code-snippet-chat-bot
    For access, request access on the workspace listed there. We'll get to you
    as soon as we can. (Post something in that chat room as well so we know who
    you are.)
    
    This is using ProgramFOX's base for SE Chatbots. The original repository is:
         https://github.com/ProgramFOX/SE-Chatbot
    
    This bot is named after the greatest character from 
        Star Trek: The Next Generation.
        
    Current Developers:
    
    Here:               PPCG:                   GitHub:
              Ryan R.       (@Mego)                 https://github.com/Mego
        Conor O'Brien       (@CᴏɴᴏʀO'Bʀɪᴇɴ)         https://github.com/ConorOBrien-Foxx
        VTCAKAVSMoACE       (@VoteToClose)          https://github.com/VTCAKAVSMoACE
             quartata       (@quartata)             https://github.com/quartata
             
    Note to Devs: to kill all instances of Data, use:
        killall python3
    That should do the trick.