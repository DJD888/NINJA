# The modules listed in this file can be read and loaded as a MetaModule into another MetaModule by the load_module() function

modules = [  # A list of all (Meta)Modules in this MetaModule.
    # '<module name>', # relative path to file (from this file), folders seperated by dots + filename minus .py
    # '<module name>'
    # ...
]

# module_name = "<name used to address this module>"
