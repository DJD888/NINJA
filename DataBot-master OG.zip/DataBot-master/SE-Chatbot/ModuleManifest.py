module_file_names = [
    'botbuiltins.module_controls',
    'botbuiltins.admin',
    'botbuiltins.nesting',
    'botbuiltins.parameters',
    'botbuiltins.utils',
    'EvalModule',
]

# You can add more modules there in the following format:
# 1. Drop the .py from a file name.
# 2. In case your module is in a subdirectory,
#    make sure that there is an __init__.py file in that subdirectory,
#    and replace (back)slashes with dots when you add them here.
