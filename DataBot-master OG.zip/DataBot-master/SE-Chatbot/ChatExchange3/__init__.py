"""
The ChatExchange package
"""
