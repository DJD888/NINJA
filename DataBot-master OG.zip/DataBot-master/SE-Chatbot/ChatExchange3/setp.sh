#!/bin/bash
echo "Make sure you source this file instead of simply running it!"
read -p "Username: " u
export ChatExchangeU=$u
export CEU="h"
stty -echo
read -p "Password: " p
export ChatExchangeP=$p
stty echo
