modules = [
    'utils',
    'fun',
    'xkcd',
    'random_',
    'translate',
    'admin',
    'didyoumean',
    'parameters',
    'module_controls',
    'nesting',
    'define'
]
module_name = "builtins"
