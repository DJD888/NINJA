SE-Chatbot: Builtins
=
This repository contains the builtins for [SE-Chatbot](https://github.com/ProgramFOX/SE-Chatbot). They are licensed under the Code Project Open License v1.02. See LICENSE.md for a copy.