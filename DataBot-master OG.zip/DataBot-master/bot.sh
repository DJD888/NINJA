#!/bin/bash
cd SE-Chatbot
./run.sh -c Test
