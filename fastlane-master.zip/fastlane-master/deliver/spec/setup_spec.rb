require 'deliver/setup'

describe Deliver do
  describe Deliver::Setup do
    it "properly downloads existing metadata" do
      # app = "app"
      # version = "version"
      # allow(Spaceship::Application).to receive(:find).and_return(app)
      # expect(app).to receive(:latest_version).and_return(version)
      # expect(version).to receive(:name).and_return("name")

      # options = {
      #   app_identifier: "tools.fastlane.app",
      #   username: "flapple@krausefx.com",
      # }
      # Deliver::Runner.new(options) # to login
      # Deliver::Setup.new.run(options)
    end
  end
end
