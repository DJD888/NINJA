require_relative 'stubbing.rb'
