# [cert](https://github.com/fastlane/fastlane/tree/master/cert)

#### To create a new certificate and a provisioning profile you have to do the following steps on the Apple Developer Portal

![assets/manual/Step1.png](assets/manual/Step1.png)
![assets/manual/Step2.png](assets/manual/Step2.png)
![assets/manual/Step3.png](assets/manual/Step3.png)
![assets/manual/Step4.png](assets/manual/Step4.png)
![assets/manual/Step5.png](assets/manual/Step5.png)
![assets/manual/Step6.png](assets/manual/Step6.png)
![assets/manual/Step7.png](assets/manual/Step7.png)
![assets/manual/Step8.png](assets/manual/Step8.png)
![assets/manual/Step9.png](assets/manual/Step9.png)
![assets/manual/Step10.png](assets/manual/Step10.png)
![assets/manual/Step11.png](assets/manual/Step11.png)
![assets/manual/Step12.png](assets/manual/Step12.png)


#### Yes, you have to follow all those steps to create a provisiong profile with its certificate
