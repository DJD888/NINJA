# Codesigning

Moved to [docs.fastlane.tools](https://docs.fastlane.tools/codesigning/Troubleshooting/)
