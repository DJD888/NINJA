#### Disclaimer

All product names, logos, and brands are property of their respective owners.  
The used device frames were provided by Facebook via the [Facebook Design Resources](https://facebook.github.io/design/devices.html). `fastlane` is in no way affiliated with Facebook.

> While Facebook has redrawn and shares these assets for the benefit of the design community, Facebook does not own any of the underlying product or user interface designs. By accessing these assets, you agree to obtain all necessary permissions from the underlying rights holders and/or adhere to any applicable brand use guidelines before using them. Facebook disclaims all express or implied warranties with respect to these assets, including non-infringement of intellectual property rights.
