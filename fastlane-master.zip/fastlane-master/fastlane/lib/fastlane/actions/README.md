All built-in integrations are available in this directory. Use the `fastlane new_action` command to create a new action.

`fastlane` will automatically detect the files in this folder
