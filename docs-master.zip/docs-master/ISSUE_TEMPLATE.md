Issues submitted here should pertain to bugs/features of our [docs site](https://docs.fastlane.tools/).

If you're looking to submit an issue (bug/question/feature) about _fastlane_ itself, please do so in the [main repo](https://github.com/fastlane/fastlane/issues). 

