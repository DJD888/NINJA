### Available Plugins

To get an up to date list of all available plugins run

```no-highlight
fastlane search_plugins
```

To search for a specific plugin

```no-highlight
fastlane search_plugins [search_query]
```

You can find more information about how to start using plugins in [_fastlane_ Plugins](https://docs.fastlane.tools/plugins/create-plugin/).

#### List of plugins

The list of available plugins was moved to the [Actions#Plugins](https://docs.fastlane.tools/actions/#plugins)
